dispatchery
===========

GUI for dispatching cases
-------------------------

Built in meteor so all the reactivities
